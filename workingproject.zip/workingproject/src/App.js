
import './App.css';

import Booking from "./pages/Booking";

function App() {
  return (
    <div className="App">
            <Booking />
      

      
    </div>
  );
}

export default App;
